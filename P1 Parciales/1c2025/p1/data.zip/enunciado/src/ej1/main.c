#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../test_utils/test-utils.h"
#include "ej1.h"

int main(int argc, char* argv[]) {
	
}